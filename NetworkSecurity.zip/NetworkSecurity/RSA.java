import java.io.IOException;
import java.math.BigInteger;
import java.util.*;
 
public class RSA
{
    BigInteger p;
    BigInteger q;
    BigInteger N;
    BigInteger phi;
    BigInteger e;
    BigInteger d;
    int bitlength = 1024;
    Random r;
 
    public RSA()
    {
        r = new Random();
        p = BigInteger.probablePrime(bitlength, r);
        q = BigInteger.probablePrime(bitlength, r);
        N = p.multiply(q);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        e = BigInteger.probablePrime(bitlength / 2, r);
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
            e.add(BigInteger.ONE);

        d = e.modInverse(phi);
    }
 
    public static void main(String[] args) throws IOException
    {
        RSA rsa = new RSA();
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the plain text: ");
        String input = scan.nextLine();
		
        System.out.println("String in Bytes: " + bytesToString(input.getBytes()));
        
        byte[] encrypted = rsa.encrypt(input.getBytes());
        //System.out.println("Encrypted String: ");
		//System.out.print(new String(encrypted));
		
        byte[] decrypted = rsa.decrypt(encrypted);
        System.out.println("Decrypted String: " + new String(decrypted));
    }
 
    private static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
    }
	
    public byte[] encrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(e, N).toByteArray();
    }

    public byte[] decrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(d, N).toByteArray();
    }
}