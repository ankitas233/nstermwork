import java.util.*;
import java.io.*;
import java.net.*;

public class q3tcp
{
	public static void main(String args[]) throws IOException
	{
		Scanner scan = new Scanner(System.in);
		Socket cs = new Socket("127.0.0.1",3333);
		
		DataOutputStream out = new DataOutputStream(cs.getOutputStream());
		
		while(true)
		{
			System.out.println("Enter Server number: ");
			String no = scan.next();
			
			System.out.println("Enter Message for Server" + no + ": ");
			String msg = scan.next();
			
			out.writeUTF(no+msg);
			if(msg.equalsIgnoreCase("exit"))
			{
				System.out.println("Client Ended..");
				break;
			}
			System.out.println("String: " + msg + " sent Successfully to Server" + no);
		}
	}
}
