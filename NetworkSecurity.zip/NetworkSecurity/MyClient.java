import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import javax.crypto.spec.SecretKeySpec;
import java.util.Scanner;
public class MyClient
{
 static String message;
 static String session_key;
 static SecretKeySpec clientkey,KDCkey;

 public static void main(String[] args) throws Exception
 {
 Scanner scan = new Scanner(System.in);

 System.out.println("Client requesting Session key from KDC to communicate..");
 clientkey = new SecretKeySpec("12345678".getBytes(),"DES");
 KDCkey = new SecretKeySpec("87654321".getBytes(),"DES");

 Socket clientsocket = new Socket("localhost",9090);
 DataOutputStream out = new DataOutputStream(clientsocket.getOutputStream());
 out.writeUTF(clientkey+"");

 DataInputStream input = new DataInputStream(clientsocket.getInputStream());
 session_key = input.readUTF();

 System.out.println("Connecting Server to Communicate..");

 clientsocket = new Socket("localhost",8811);
 System.out.print("\nEnter Message to Send to Server: ");
 String message = scan.nextLine();
 out = new DataOutputStream(clientsocket.getOutputStream());

 out.writeUTF(message+"_@_"+session_key);
 System.out.println("Message Sent..");
 }
}