import java.util.*;
import java.io.*;
import java.net.*;
public class Server1 {
    public static void main(String args[]) throws IOException {
        ServerSocket ss = new ServerSocket(1234);
        Socket con = ss.accept();
        DataInputStream input = new DataInputStream(con.getInputStream());
        System.out.println("Server1 Started...");
        while (true) {
            String msg = input.readUTF();

            if (msg.equalsIgnoreCase("exit")) {
                System.out.println("Server1 Closing...");
                break;
            }
            System.out.println("Message for Server1: " + msg);
        }
    }
}