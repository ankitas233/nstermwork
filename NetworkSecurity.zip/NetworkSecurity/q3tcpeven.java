import java.util.*;
import java.io.*;
import java.net.*;

public class q3tcpeven
{
	public static void main(String args[]) throws IOException
	{
			ServerSocket ds=new ServerSocket(1234);	
		while(true)
		{
			String es="";
			Socket sk=ds.accept();
			BufferedReader br=new BufferedReader(new InputStreamReader(sk.getInputStream()));
			es=br.readLine();
			if(es.equalsIgnoreCase("exit"))
			{
				System.out.println("Exiting!");
				break;
			}
			System.out.println("Even number: "+es+" successfully received!");	
		}		
	}
}
