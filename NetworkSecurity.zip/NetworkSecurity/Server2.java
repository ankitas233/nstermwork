import java.util.*;
import java.io.*;
import java.net.*;
public class Server2 {
    public static void main(String args[]) throws IOException {
        ServerSocket ss = new ServerSocket(3456);
        Socket con = ss.accept();
        DataInputStream input = new DataInputStream(con.getInputStream());
        System.out.println("Server2 Started...");
        while (true) {
            String msg = input.readUTF();

            if (msg.equalsIgnoreCase("exit")) {
                System.out.println("Server2 Closing...");
                break;
            }
            System.out.println("Message for Server2: " + msg);
        }
    }
}