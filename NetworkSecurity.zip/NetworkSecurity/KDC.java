import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import javax.crypto.spec.SecretKeySpec;
public class KDC
{
 static SecretKeySpec clientkey;
 static byte [] sessionkey;

 public static void main(String[] args) throws Exception
 {
 System.out.println("KDC Started...");

 clientkey = new SecretKeySpec("12345678".getBytes(),"DES");

 ServerSocket ss = new ServerSocket(9090);
 Socket con = ss.accept();

 sessionkey = generateSessionKey();
 System.out.println("Generated Session Key: " + new String(sessionkey));

 DataInputStream input = new DataInputStream(con.getInputStream());
 String receivedkey = input.readUTF();

 DataOutputStream out = new DataOutputStream(con.getOutputStream());
 if((clientkey+"").equals(receivedkey))
 {
 out.writeUTF(sessionkey+""); 
 System.out.println("Session Key sent to Client");

 Socket KDCsocket = new Socket("localhost",8888);
 out = new DataOutputStream(KDCsocket.getOutputStream());

 out.writeUTF(sessionkey+"");
 System.out.println("Session Key sent to Server");
 }
 else
 {
 out.writeUTF("Invalid Client..");
 System.out.println("Invalid Client..");
 }
 }

 public static byte [] generateSessionKey() throws Exception
 {
 sessionkey = new byte[8];
 SecureRandom random = new SecureRandom();
 random.nextBytes(sessionkey);
 return sessionkey;
 }
}