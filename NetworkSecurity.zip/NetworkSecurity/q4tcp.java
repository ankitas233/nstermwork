import java.util.*;
import java.io.*;
import java.net.*;

public class q4tcp
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		Socket ds=new Socket("127.0.0.1",1234);
		DataOutputStream dos=new DataOutputStream(ds.getOutputStream());
		String un,p,eun,ep;
			System.out.println("Enter Username: ");
			un=sc.nextLine();
			System.out.println("Enter Password: ");
			p=sc.nextLine();
			eun=encrypt(un,5);
			ep=encrypt(p,5);
			dos.writeBytes(eun+"\n");
			dos.writeBytes(ep+"\n");
		BufferedReader br=new BufferedReader(new InputStreamReader(ds.getInputStream()));
		String ack=br.readLine();
		System.out.println(ack);
	}
	public static String encrypt(String s, int k)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)<=96+k && s.charAt(i)>=97)
				{
					c=(char)(s.charAt(i)+(26-k));
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)<=(64+k))
				{
					c=(char)(s.charAt(i)+(26-k));
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)-k);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)<=47+k)
				{
					c=(char)(s.charAt(i)+(10-k));
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)-k);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}
